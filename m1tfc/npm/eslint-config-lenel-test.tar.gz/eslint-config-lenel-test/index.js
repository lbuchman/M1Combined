module.exports = {
  rules: {
    'import/no-extraneous-dependencies': [2, { devDependencies: true } ],
    'func-names':  'off',
    'prefer-arrow-callback': 'off',
    'no-unused-expressions': 'off'
  },
  extends: [
    '@lenel/eslint-config-lenel-base'
  ].map(require.resolve)
};