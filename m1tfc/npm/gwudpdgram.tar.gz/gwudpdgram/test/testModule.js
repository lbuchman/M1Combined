'use strict';

const chai = require('chai');

describe('Validate datagram module : ', () => {
    it('|=> just a fake test to pass jenkins validation', () => {
        const someValue = 2;
        return chai.expect(someValue).to.not.be.equal(1);
    });
});
